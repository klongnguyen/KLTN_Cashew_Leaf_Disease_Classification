# EXP-Y26S-NEG-V03-001-CLASS-WEIGHTED

Dataset: /content/exp_yolo_neg_v03_weighted/CASHEW_YOLO_MASTER_FINAL_NEG_V03 (2).zip; Train/Val/Test = 3497/951/412.
Classes: ['anthracnose', 'leaf_miner', 'red_rust']. Healthy và not_cashew_leaf là ảnh âm 0 box.
Model: yolo26s.pt, seed 42, cls_pw=0.25. Trọng số: {'anthracnose': 0.7780247926712036, 'leaf_miner': 1.5752495527267456, 'red_rust': 0.6467254757881165}.
Validation mAP50=0.7163, mAP50-95=0.3981.
Leaf Miner: {'class_id': 1, 'class': 'leaf_miner', 'precision': 0.7283754019728214, 'recall': 0.7341549295774648, 'ap50': 0.7908244905577256, 'ap50_95': 0.5149242867025986, 'train_boxes': 2076, 'class_weight': 1.5752495527267456}.
Preflight: metadata/negative_image_preflight.json.
So sánh baseline: Chưa có baseline cls_pw=0 trên cùng NEG_V03.

So sánh YOLO26s/YOLOv8s: xem model_comparison.csv và model_comparison.json. Một seed cho mỗi model; chênh lệch chưa chứng minh tính ổn định.
