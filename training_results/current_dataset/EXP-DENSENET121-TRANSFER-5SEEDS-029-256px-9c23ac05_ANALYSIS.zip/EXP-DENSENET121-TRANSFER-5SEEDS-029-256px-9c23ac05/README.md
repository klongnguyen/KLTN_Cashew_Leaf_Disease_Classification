# EXP-DENSENET121-TRANSFER-5SEEDS-029-256px-9c23ac05

DenseNet121 + RandomBrightness(0.08), configured dataset, 256x256.

Deployment seed selected by Validation loss: 3407.
Test: FINAL_TEST_EVALUATED; configured real holdout: REAL_HOLDOUT_EVALUATED. Neither evaluation selects the model or seed.
See validation_decision_note.json. No automatic promotion or WebApp replacement.
Paired-seed CI on one split is not a field-population CI.
